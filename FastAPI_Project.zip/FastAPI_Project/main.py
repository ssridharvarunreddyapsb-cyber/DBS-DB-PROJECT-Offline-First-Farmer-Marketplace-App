from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from fastapi.responses import FileResponse
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import secrets

app = FastAPI(title="Mandi Mitra API")
BASE_DIR = Path(__file__).resolve().parent

# ============================================================
# CORS - Allows your HTML frontend to communicate with FastAPI
# ============================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5500",
        "http://127.0.0.1:5500",
        "http://localhost:5173",
        "http://127.0.0.1:5173"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================
# MONGODB CONNECTION
# ============================================================

client = MongoClient("mongodb://localhost:27017/")

db = client["mandi_mitra"]

# New account records are stored in `users`, while `farmers` remains readable
# for compatibility with accounts created by the earlier version of the app.
farmers_collection = db["users"]
legacy_farmers_collection = db["farmers"]
products_collection = db["products"]
messages_collection = db["messages"]


# ============================================================
# DATA MODELS
# ============================================================

class Farmer(BaseModel):
    name: str
    email: str
    phone: str
    role: str
    city: str
    state: str
    pin: str | None = None


class LoginRequest(BaseModel):
    phone: str
    pin: str


class Product(BaseModel):
    farmer_id: str
    farmer_name: str
    name: str
    description: str = ""
    quantity: float
    unit: str
    price: float
    ready_by: str = ""
    status: str = "active"


class ChatMessage(BaseModel):
    sender_id: str
    sender_name: str
    recipient_id: str
    recipient_name: str
    body: str
    product_id: str = ""


def object_id_or_400(value: str):
    from bson import ObjectId

    if not ObjectId.is_valid(value):
        raise HTTPException(status_code=400, detail="Invalid resource id")
    return ObjectId(value)


def serialize_user(user: dict):
    """Normalize older farmer records so the frontend can use every account."""
    # Credentials must never be returned to a browser or another API consumer.
    user.pop("pin", None)
    user.pop("pin_hash", None)
    user.pop("pin_salt", None)
    user["_id"] = str(user["_id"])
    user.setdefault("email", "")
    user.setdefault("phone", "")
    user.setdefault("role", "farmer")
    user.setdefault("city", user.get("village", user.get("district", "")))
    user.setdefault("state", "")
    return user


def valid_pin(pin: str | None) -> bool:
    return bool(pin and pin.isdigit() and 4 <= len(pin) <= 6)


def hash_pin(pin: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), salt.encode("utf-8"), 310_000).hex()


def find_user_by_phone(phone: str):
    return farmers_collection.find_one({"phone": phone}) or legacy_farmers_collection.find_one({"phone": phone})


def seed_marketplace_if_empty():
    """Add any missing first-run Browse catalog items directly to MongoDB."""

    sellers = {
        "Lakshmi Farms": "a1b2c3d4e5f60718293a4b5c",
        "Sunrise Orchards": "b1c2d3e4f5a60718293a4b5c",
        "Green Valley Dairy": "c1d2e3f4a5b60718293a4b5c",
    }
    listings = [
        ("Lakshmi Farms", "Tomatoes", "Fresh red tomatoes, picked this morning.", 35, "kg", 32, "2026-09-16"),
        ("Lakshmi Farms", "Potatoes", "Clean, firm farm potatoes for everyday cooking.", 50, "kg", 28, "2026-09-16"),
        ("Lakshmi Farms", "Carrots", "Sweet orange carrots, naturally grown.", 20, "kg", 45, "2026-09-17"),
        ("Lakshmi Farms", "Spinach", "Fresh leafy spinach bunches.", 18, "bag", 25, "2026-09-16"),
        ("Sunrise Orchards", "Bananas", "Naturally ripened yellow bananas.", 12, "dozen", 55, "2026-09-16"),
        ("Sunrise Orchards", "Mangoes", "Seasonal sweet mangoes from the orchard.", 25, "kg", 90, "2026-09-18"),
        ("Sunrise Orchards", "Guavas", "Juicy, vitamin-rich guavas.", 16, "kg", 65, "2026-09-17"),
        ("Green Valley Dairy", "Fresh Cow Milk", "Pure chilled cow milk, delivered fresh daily.", 30, "bag", 60, "2026-09-16"),
        ("Green Valley Dairy", "Homemade Curd", "Thick, fresh-set curd with no additives.", 15, "kg", 85, "2026-09-16"),
        ("Green Valley Dairy", "Paneer", "Soft, fresh paneer made from full-cream milk.", 10, "kg", 380, "2026-09-17"),
        ("Green Valley Dairy", "Desi Ghee", "Traditional aromatic ghee, small-batch prepared.", 8, "kg", 720, "2026-09-17"),
    ]
    existing_names = {
        str(product.get("name", "")).strip().lower()
        for product in products_collection.find({}, {"name": 1})
    }
    starter_products = [
        {
            "farmer_id": sellers[seller], "farmer_name": seller, "name": name,
            "description": description, "quantity": quantity, "unit": unit,
            "price": price, "ready_by": ready_by, "status": "active",
        }
        for seller, name, description, quantity, unit, price, ready_by in listings
        if name.lower() not in existing_names
    ]
    if starter_products:
        products_collection.insert_many(starter_products)


@app.on_event("startup")
def initialise_database():
    client.admin.command("ping")
    seed_marketplace_if_empty()


# ============================================================
# HOME
# ============================================================

@app.get("/")
def home():
    return FileResponse(BASE_DIR / "farmer-marketplace.html")


@app.get("/api/health")
def health_check():
    return {"message": "Mandi Mitra API is working!"}


# ============================================================
# CREATE FARMER
# ============================================================

@app.post("/farmers")
def add_farmer(farmer: Farmer):

    if not valid_pin(farmer.pin):
        raise HTTPException(status_code=422, detail="PIN must contain 4 to 6 digits")

    farmer_data = farmer.model_dump(exclude={"pin"})
    salt = secrets.token_hex(16)
    farmer_data["pin_salt"] = salt
    farmer_data["pin_hash"] = hash_pin(farmer.pin, salt)

    if farmers_collection.find_one({"phone": farmer.phone}) or legacy_farmers_collection.find_one({"phone": farmer.phone}):
        raise HTTPException(status_code=409, detail="An account with this phone already exists")

    try:
        result = farmers_collection.insert_one(farmer_data)
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="An account with this phone already exists")

    return {
        "message": "Farmer added successfully",
        "id": str(result.inserted_id)
    }


# ============================================================
# GET ALL FARMERS
# ============================================================

@app.get("/farmers")
def get_farmers():

    users = list(farmers_collection.find()) + list(legacy_farmers_collection.find())
    return [serialize_user(user) for user in users]


@app.get("/users")
def get_users():
    return get_farmers()


@app.get("/farmers/by-phone/{phone}")
def get_farmer_by_phone(phone: str):
    farmer = farmers_collection.find_one({"phone": phone}) or legacy_farmers_collection.find_one({"phone": phone})
    if farmer is None:
        raise HTTPException(status_code=404, detail="Farmer not found")

    return serialize_user(farmer)


@app.put("/farmers/{farmer_id}")
def update_farmer(farmer_id: str, farmer: Farmer):
    user_id = object_id_or_400(farmer_id)
    result = farmers_collection.update_one({"_id": user_id}, {"$set": farmer.model_dump()})
    if result.matched_count == 0:
        result = legacy_farmers_collection.update_one({"_id": user_id}, {"$set": farmer.model_dump()})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Farmer not found")

    return {"message": "Farmer updated successfully"}


# ============================================================
# CREATE PRODUCT
# ============================================================

@app.post("/products")
def add_product(product: Product):

    product_data = product.model_dump()

    result = products_collection.insert_one(product_data)

    return {
        "message": "Product added successfully",
        "id": str(result.inserted_id)
    }


# ============================================================
# GET ALL PRODUCTS
# ============================================================

@app.get("/products")
def get_products():

    products = list(products_collection.find())

    for product in products:
        product["_id"] = str(product["_id"])

    return products


@app.put("/products/{product_id}")
def update_product(product_id: str, product: Product):
    result = products_collection.replace_one(
        {"_id": object_id_or_400(product_id)},
        product.model_dump()
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")

    return {"message": "Product updated successfully"}


# ============================================================
# DELETE PRODUCT
# ============================================================

@app.delete("/products/{product_id}")
def delete_product(product_id: str):
    result = products_collection.delete_one(
        {"_id": object_id_or_400(product_id)}
    )

    if result.deleted_count == 0:
        return {
            "message": "Product not found"
        }

    return {
        "message": "Product deleted successfully"
    }


@app.post("/auth/login")
def login(credentials: LoginRequest):
    user = find_user_by_phone(credentials.phone)
    if user is None or not valid_pin(credentials.pin):
        raise HTTPException(status_code=401, detail="Invalid phone number or PIN")

    salt = user.get("pin_salt")
    saved_hash = user.get("pin_hash")
    if not salt or not saved_hash or not secrets.compare_digest(hash_pin(credentials.pin, salt), saved_hash):
        raise HTTPException(status_code=401, detail="Invalid phone number or PIN")

    return serialize_user(user)


# ============================================================
# CHAT MESSAGES
# ============================================================

@app.post("/messages")
def send_message(message: ChatMessage):
    message_data = message.model_dump()
    message_data["body"] = message_data["body"].strip()
    if not message_data["body"]:
        raise HTTPException(status_code=422, detail="Message cannot be empty")

    message_data["created_at"] = datetime.now(timezone.utc).isoformat()
    result = messages_collection.insert_one(message_data)
    return {"message": "Message sent", "id": str(result.inserted_id)}


@app.get("/messages/{user_id}")
def get_messages(user_id: str, peer_id: str | None = None):
    query = {"$or": [{"sender_id": user_id}, {"recipient_id": user_id}]}
    if peer_id:
        query = {
            "$or": [
                {"sender_id": user_id, "recipient_id": peer_id},
                {"sender_id": peer_id, "recipient_id": user_id},
            ]
        }

    messages = list(messages_collection.find(query).sort("created_at", 1))
    for message in messages:
        message["_id"] = str(message["_id"])
    return messages
