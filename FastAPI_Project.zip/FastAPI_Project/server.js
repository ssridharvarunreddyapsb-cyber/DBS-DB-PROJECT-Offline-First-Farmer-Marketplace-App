/*
 * Mandi Mitra local server
 *
 * This intentionally uses only Node's standard library so the project can run
 * on a fresh machine without Python, MongoDB, or an npm install.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { randomBytes } = require('crypto');

const PORT = Number(process.env.PORT) || 8000;
const ROOT = __dirname;
const DATA_FILE = path.join(ROOT, 'mandi-mitra-data.json');

function emptyData() {
  return { users: [], products: [], messages: [] };
}

function starterData() {
  const farmers = [
    { _id: id(), name: 'Lakshmi Farms', email: 'lakshmi@mandi.local', phone: '9000000001', role: 'farmer', city: 'Rangareddy', state: 'Telangana' },
    { _id: id(), name: 'Green Valley Dairy', email: 'greenvalley@mandi.local', phone: '9000000002', role: 'farmer', city: 'Medchal', state: 'Telangana' },
    { _id: id(), name: 'Sunrise Orchards', email: 'sunrise@mandi.local', phone: '9000000003', role: 'farmer', city: 'Vikarabad', state: 'Telangana' },
  ];
  const [lakshmi, dairy, orchards] = farmers;
  const product = (farmer, name, description, quantity, unit, price, ready_by) => ({
    _id: id(), farmer_id: farmer._id, farmer_name: farmer.name, name, description,
    quantity, unit, price, ready_by, status: 'active',
  });
  return {
    users: farmers,
    products: [
      product(lakshmi, 'Tomatoes', 'Fresh red tomatoes, picked this morning.', 35, 'kg', 32, '2026-09-16'),
      product(lakshmi, 'Potatoes', 'Clean, firm farm potatoes for everyday cooking.', 50, 'kg', 28, '2026-09-16'),
      product(lakshmi, 'Carrots', 'Sweet orange carrots, naturally grown.', 20, 'kg', 45, '2026-09-17'),
      product(lakshmi, 'Spinach', 'Fresh leafy spinach bunches.', 18, 'bag', 25, '2026-09-16'),
      product(orchards, 'Bananas', 'Naturally ripened yellow bananas.', 12, 'dozen', 55, '2026-09-16'),
      product(orchards, 'Mangoes', 'Seasonal sweet mangoes from the orchard.', 25, 'kg', 90, '2026-09-18'),
      product(orchards, 'Guavas', 'Juicy, vitamin-rich guavas.', 16, 'kg', 65, '2026-09-17'),
      product(dairy, 'Fresh Cow Milk', 'Pure chilled cow milk, delivered fresh daily.', 30, 'bag', 60, '2026-09-16'),
      product(dairy, 'Homemade Curd', 'Thick, fresh-set curd with no additives.', 15, 'kg', 85, '2026-09-16'),
      product(dairy, 'Paneer', 'Soft, fresh paneer made from full-cream milk.', 10, 'kg', 380, '2026-09-17'),
      product(dairy, 'Desi Ghee', 'Traditional aromatic ghee, small-batch prepared.', 8, 'kg', 720, '2026-09-17'),
    ],
    messages: [],
  };
}

function loadData() {
  try {
    const saved = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return {
      users: Array.isArray(saved.users) ? saved.users : [],
      products: Array.isArray(saved.products) ? saved.products : [],
      messages: Array.isArray(saved.messages) ? saved.messages : [],
    };
  } catch (error) {
    return starterData();
  }
}

let data = loadData();

function saveData() {
  fs.writeFileSync(DATA_FILE, `${JSON.stringify(data, null, 2)}\n`, 'utf8');
}

// Persist the first-run catalog so its listings and seller IDs stay stable
// across restarts.
if (!fs.existsSync(DATA_FILE)) saveData();

function id() {
  // 24 hexadecimal characters, matching MongoDB ObjectId-shaped IDs expected
  // by the existing frontend.
  return randomBytes(12).toString('hex');
}

function send(response, status, body, headers = {}) {
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
  response.end(JSON.stringify(body));
}

function notFound(response, detail = 'Not found') {
  return send(response, 404, { detail });
}

function validPhone(phone) {
  return typeof phone === 'string' && /^\d{10}$/.test(phone);
}

function validUser(user) {
  return user && typeof user.name === 'string' && typeof user.email === 'string'
    && validPhone(user.phone) && ['farmer', 'buyer'].includes(user.role)
    && typeof user.city === 'string' && typeof user.state === 'string';
}

function validProduct(product) {
  return product && typeof product.farmer_id === 'string'
    && typeof product.farmer_name === 'string' && typeof product.name === 'string'
    && typeof product.description === 'string' && Number.isFinite(product.quantity)
    && typeof product.unit === 'string' && Number.isFinite(product.price)
    && typeof product.ready_by === 'string' && ['active', 'sold'].includes(product.status);
}

function readJson(request) {
  return new Promise((resolve, reject) => {
    let raw = '';
    request.on('data', chunk => {
      raw += chunk;
      if (raw.length > 1_000_000) request.destroy();
    });
    request.on('end', () => {
      try { resolve(raw ? JSON.parse(raw) : {}); }
      catch { reject(new Error('Request body must be valid JSON')); }
    });
    request.on('error', reject);
  });
}

function withCors(response) {
  response.setHeader('Access-Control-Allow-Origin', '*');
  response.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  response.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

async function handleApi(request, response, url) {
  const { method } = request;
  const segments = url.pathname.split('/').filter(Boolean).map(decodeURIComponent);

  if (method === 'OPTIONS') return response.end();
  if (method === 'GET' && url.pathname === '/api/health') {
    return send(response, 200, { message: 'Mandi Mitra API is working!' });
  }

  if (method === 'GET' && url.pathname === '/farmers') return send(response, 200, data.users);
  if (method === 'GET' && url.pathname === '/users') return send(response, 200, data.users);
  if (method === 'GET' && segments[0] === 'farmers' && segments[1] === 'by-phone' && segments[2]) {
    const user = data.users.find(item => item.phone === segments[2]);
    return user ? send(response, 200, user) : notFound(response, 'Farmer not found');
  }
  if (method === 'POST' && url.pathname === '/farmers') {
    const user = await readJson(request);
    if (!validUser(user)) return send(response, 422, { detail: 'Invalid account details' });
    if (data.users.some(item => item.phone === user.phone)) {
      return send(response, 409, { detail: 'An account with this phone already exists' });
    }
    const saved = { ...user, _id: id() };
    data.users.push(saved);
    saveData();
    return send(response, 201, { message: 'Farmer added successfully', id: saved._id });
  }
  if (method === 'PUT' && segments[0] === 'farmers' && segments[1]) {
    const user = await readJson(request);
    const index = data.users.findIndex(item => item._id === segments[1]);
    if (index < 0) return notFound(response, 'Farmer not found');
    if (!validUser(user)) return send(response, 422, { detail: 'Invalid account details' });
    if (data.users.some((item, i) => i !== index && item.phone === user.phone)) {
      return send(response, 409, { detail: 'An account with this phone already exists' });
    }
    data.users[index] = { ...user, _id: segments[1] };
    saveData();
    return send(response, 200, { message: 'Farmer updated successfully' });
  }

  if (method === 'GET' && url.pathname === '/products') return send(response, 200, data.products);
  if (method === 'POST' && url.pathname === '/products') {
    const product = await readJson(request);
    if (!validProduct(product)) return send(response, 422, { detail: 'Invalid product details' });
    const saved = { ...product, _id: id() };
    data.products.push(saved);
    saveData();
    return send(response, 201, { message: 'Product added successfully', id: saved._id });
  }
  if (method === 'PUT' && segments[0] === 'products' && segments[1]) {
    const product = await readJson(request);
    const index = data.products.findIndex(item => item._id === segments[1]);
    if (index < 0) return notFound(response, 'Product not found');
    if (!validProduct(product)) return send(response, 422, { detail: 'Invalid product details' });
    data.products[index] = { ...product, _id: segments[1] };
    saveData();
    return send(response, 200, { message: 'Product updated successfully' });
  }
  if (method === 'DELETE' && segments[0] === 'products' && segments[1]) {
    const before = data.products.length;
    data.products = data.products.filter(item => item._id !== segments[1]);
    if (data.products.length === before) return send(response, 200, { message: 'Product not found' });
    saveData();
    return send(response, 200, { message: 'Product deleted successfully' });
  }

  if (method === 'POST' && url.pathname === '/messages') {
    const message = await readJson(request);
    const required = ['sender_id', 'sender_name', 'recipient_id', 'recipient_name', 'body'];
    if (!message || !required.every(key => typeof message[key] === 'string') || !message.body.trim()) {
      return send(response, 422, { detail: 'Message cannot be empty' });
    }
    const saved = { ...message, body: message.body.trim(), product_id: message.product_id || '', _id: id(), created_at: new Date().toISOString() };
    data.messages.push(saved);
    saveData();
    return send(response, 201, { message: 'Message sent', id: saved._id });
  }
  if (method === 'GET' && segments[0] === 'messages' && segments[1]) {
    const userId = segments[1];
    const peerId = url.searchParams.get('peer_id');
    const messages = data.messages.filter(message => peerId
      ? (message.sender_id === userId && message.recipient_id === peerId)
        || (message.sender_id === peerId && message.recipient_id === userId)
      : message.sender_id === userId || message.recipient_id === userId,
    ).sort((a, b) => a.created_at.localeCompare(b.created_at));
    return send(response, 200, messages);
  }

  return notFound(response);
}

const server = http.createServer(async (request, response) => {
  withCors(response);
  const url = new URL(request.url, `http://${request.headers.host || 'localhost'}`);
  try {
    if (url.pathname === '/' && request.method === 'GET') {
      const file = path.join(ROOT, 'farmer-marketplace.html');
      response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return fs.createReadStream(file).pipe(response);
    }
    return await handleApi(request, response, url);
  } catch (error) {
    console.error(error);
    return send(response, 400, { detail: error.message || 'Bad request' });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`Mandi Mitra is running at http://127.0.0.1:${PORT}`);
});
